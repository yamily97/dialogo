package com.example.dialogos_practica2;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class asistente {

    public class AsistenteActivity extends AppCompatActivity {
        private Spinner spinner;
        private Button btnAsistente;

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.asistente);

            spinner = findViewById(R.id.spinner);
            btnAsistente = findViewById(R.id.btnAsistente);

            // Crear el adaptador para el spinner
            ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                    R.array.conferencias_array, android.R.layout.simple_spinner_item);
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

            // Asignar el adaptador al spinner
            spinner.setAdapter(adapter);

            btnAsistente.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    // Obtener la conferencia seleccionada
                    String conferencia = spinner.getSelectedItem().toString();

                    // Guardar los datos en algún lugar (por ejemplo, en una base de datos o en SharedPreferences)

                    // Mostrar mensaje de registro exitoso
                    Toast.makeText(AsistenteActivity.this, "Registro exitoso", Toast.LENGTH_SHORT).show();
                }
            });
        }
    }

}

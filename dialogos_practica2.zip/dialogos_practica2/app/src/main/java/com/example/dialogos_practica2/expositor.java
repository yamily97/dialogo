package com.example.dialogos_practica2;

// ExpositorActivity.java
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class expositor extends AppCompatActivity {
    private EditText etNombre, etTelefono, etCorreo, etconferencia;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.expositor);

        etNombre = findViewById(R.id.etxnombre);
        etTelefono = findViewById(R.id.etxcelular);
        etCorreo = findViewById(R.id.etxCorreo);
        etconferencia = findViewById(R.id.etxconferencia);

        Button btnRegistrar = findViewById(R.id.btnGuardar);
        btnRegistrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Obtener los datos ingresados por el expositor
                String nombre = etNombre.getText().toString();
                String telefono = etTelefono.getText().toString();
                String correo = etCorreo.getText().toString();
                String conferencia = etconferencia.getText().toString();

                // Guardar los datos en algún lugar (por ejemplo, en una base de datos o en SharedPreferences)

                // Mostrar mensaje de registro exitoso
                Toast.makeText(expositor.this, "te haz registrado con exito", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
